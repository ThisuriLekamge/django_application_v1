from django.shortcuts import render
from .models import Destination
# Create your views here.


def index(request):

    # dest1 = Destination()
    # dest1.name ="CMB"
    # dest1.desc = "I love here"
    # dest1.omg = "1.png"
    # dest1.price = "$700"
    #
    # dest2 = Destination()
    # dest2.name = "Chennai"
    # dest2.desc = "city to remember"
    # dest2.price = "$700"
    # dest2.review = True
    #
    # dest3 = Destination()
    # dest3.name = "Masala"
    # dest3.desc = "shitty"
    # dest3.price = "$700"
    #
    # desta = [dest1, dest2, dest3]

    dests = Destination.objects.all()
    return render(request, 'index.html', {'dests':dests})